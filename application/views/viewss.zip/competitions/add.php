<?=$header;?>
<div class="row">
    <div class="col-xs-12">
        <h1 class="page-header"><?=$title;?></h1>
    </div>
</div>
<div class="row">
    <div class="col-xs-12">
        <form method="post" action="<?=base_url();?>competitions/add" enctype="multipart/form-data">
            <div class="row">
                <div class="col-xs-12">
                    <label>*Image:</label>
                    <input class="form-control" name="image_url" type="file" value="<?=set_value('url');?>">
                </div>
                <?=form_error('image_url');?>
            </div>
             <div class="row">
                <div class="col-xs-12">
                    <label>*URL:</label>
                    <input class="form-control" name="url" value="<?=set_value('url');?>">
                </div>
                <?=form_error('url');?>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <label>*Title:</label>
                    <input class="form-control" name="audition_name" value="<?=set_value('audition_name');?>">
                </div>
                <?=form_error('audition_name');?>
            </div>
             <div class="row">
                <div class="col-xs-12">
                    <div class="row-xs-6">
                        <label>*Start Date:</label>
                        <input class="form-control" name="start_date" value="<?=set_value('start_date');?>">
                        <?=form_error('start_date');?>
                    </div>
                    <div class="row-xs-6">
                        <label>*End Date:</label>
                        <input class="form-control" name="end_date" value="<?=set_value('end_date');?>">
                        <?=form_error('end_date');?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <label>*Description:</label>
                    <textarea id="editor1" name="audition_description"><?=set_value('audition_description');?></textarea>
                </div>
                <?=form_error('audition_description');?>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <label>Status:</label>
                    <select class="form-control" name="is_active">
                        <option value="1">Active</option>
                        <option value="0">Inactive</option>
                    </select>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12">
                    <button class="btn btn-success">Submit</button>
                    <a href="<?=base_url();?>/news" class="btn btn-danger">Cancel</a>
                </div>
            </div>
        </form>
    </div>
</div>
<script>
    // Replace the <textarea id="editor1"> with a CKEditor
    // instance, using default configuration.
    CKEDITOR.replace( 'editor1', {
        filebrowserBrowseUrl: '<?=base_url();?>assets/ckfinder/ckfinder.html?resourceType=Files'
    });
</script>
<?=$footer;?>
